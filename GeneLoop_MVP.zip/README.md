
# GeneLoop MVP

نسخة أولية من منصة GeneLoop.

## طريقة النشر على Render:

1. اذهب إلى https://render.com
2. أنشئ حسابًا مجانيًا
3. اختر New -> Web Service
4. اربط GitHub أو ارفع الملفات يدويًا
5. اختر بيئة Node.js
6. الأمر لتشغيل التطبيق: `node server.js`
7. سيتم إنشاء رابط مجاني لك لتجربة البرنامج
